<?php
/**
 * Template Name: Mohcine Layout
 * Description: Full-width canvas for the Mohcine React bundle.
 */


get_header();
?>

<div id="mohcine-root">
	<div id="root"></div>
</div>

<?php
get_footer();
