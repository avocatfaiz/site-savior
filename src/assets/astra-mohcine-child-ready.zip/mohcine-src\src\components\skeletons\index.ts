export { default as NewsCardSkeleton, NewsGridSkeleton } from './NewsCardSkeleton';
export { default as PartnersSkeleton } from './PartnersSkeleton';
export { default as TestimonialsSkeleton } from './TestimonialsSkeleton';
export { default as ProgramsSkeleton } from './ProgramsSkeleton';
export { default as ServicesSkeleton } from './ServicesSkeleton';
export { default as HeroSkeleton } from './HeroSkeleton';
export { default as StatsSkeleton } from './StatsSkeleton';
